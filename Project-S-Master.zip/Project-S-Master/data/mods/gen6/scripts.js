'use strict';

/**@type {ModdedBattleScriptsData} */
let BattleScripts = {
	gen: 6,
};

exports.BattleScripts = BattleScripts;

